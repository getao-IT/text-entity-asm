package com.iecas.entityevaluate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EntityEvaluateApplication {

    public static void main(String[] args) {
        SpringApplication.run(EntityEvaluateApplication.class, args);
    }

}
