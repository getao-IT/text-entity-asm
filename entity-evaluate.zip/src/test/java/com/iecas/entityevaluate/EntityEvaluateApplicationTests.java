package com.iecas.entityevaluate;

import com.iecas.entityevaluate.pojo.entity.EntityInfo;
import com.iecas.entityevaluate.utils.EntityMetricsUtils;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class EntityEvaluateApplicationTests {

    private final String PRED = "F:\\AIR_work\\250529-文本实体识别评价指标\\code\\entity-evaluate\\test\\pred.txt";
    private final String TARGET = "F:\\AIR_work\\250529-文本实体识别评价指标\\code\\entity-evaluate\\test\\target.txt";

    @Test
    void extraEntityTest() {
        EntityMetricsUtils entityMetricsUtils = new EntityMetricsUtils();
        List<EntityInfo> pred = entityMetricsUtils.extraEntity(PRED);
        List<EntityInfo> target = entityMetricsUtils.extraEntity(TARGET);
        EntityMetricsUtils.computeMicroEntityMetrics(target, pred);
        EntityMetricsUtils.computePerClassMetrics(target, pred);
        EntityMetricsUtils.computePerClassMetricsFast(target, pred);
    }

}
